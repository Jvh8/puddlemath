function doGet() {
  return HtmlService.createHtmlOutputFromFile('index')
    .setTitle('Puddle Games')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
