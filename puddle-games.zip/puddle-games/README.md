# Puddle Games

A small games site with 240+ browser games, a Favorites and Continue playing row, themes, and a custom background. It is plain HTML, CSS and JavaScript. There is nothing to install.

## Features
- Thumbnail grid with search and categories, including a 2 Player category
- Favorites and Recently played, saved in the browser
- 7 themes, an animated starry background, and your own background picture (upload or link)
- Five games built in (Snake, Memory Match, Tic Tac Toe, Pong, Connect Four) plus embedded games

## Run it locally
Open `index.html` in a browser. Or serve the folder:

```bash
python3 -m http.server 8000
```

Then go to http://localhost:8000.

## Put it on GitHub Pages
1. Create a new repository on GitHub and upload everything in this folder.
2. Go to **Settings, then Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, pick `main` and `/ (root)`, then **Save**.
4. After a minute your site is live at `https://YOUR-NAME.github.io/REPO-NAME/`.

Or from a terminal:

```bash
git init
git add .
git commit -m "Puddle Games"
git branch -M main
git remote add origin https://github.com/YOUR-NAME/REPO-NAME.git
git push -u origin main
```

## Put it on Google Apps Script
1. In your Apps Script project, replace `Code.gs` with `apps-script/Code.gs`.
2. Add an HTML file named `index` and paste in `apps-script/index.html`.
3. **Deploy, then New deployment, then Web app.** Set *Execute as* to Me and *Who has access* to Anyone.

After you change anything in `css/` or `js/`, run `python3 build.py` to rebuild `apps-script/index.html`.

## Add a game
- OnlineGames.io games: add a row to `DATA` in `js/data.js`.
- TwoPlayerGames.org games: add a row to `TPG` in `js/data.js` (title, slug, category, 1 if it is a 2 player game).
- Your own game: write a function that draws into an element and returns a cleanup function, like `snake` in `js/games.js`, then add it to `GAMES` in `js/app.js`.

## Files
```
index.html          page
css/style.css       styles
js/data.js          game lists
js/games.js         built-in games and their thumbnails
js/app.js           site logic
apps-script/        Google Apps Script version
build.py            makes apps-script/index.html
```

## Credits and notes
- Embedded games come from [OnlineGames.io](https://www.onlinegames.io/t/embeddable-games-for-websites/) (free publisher program) and [TwoPlayerGames.org](https://www.twoplayergames.org/) (`/embed/` pages). The games and thumbnails belong to their developers. Check each site's terms before you publish.
- Settings and favorites use the browser's local storage. If a host blocks it, they last until the page closes.
- Game thumbnails load from the game sites. If one doesn't load, the tile shows a plain color instead.
